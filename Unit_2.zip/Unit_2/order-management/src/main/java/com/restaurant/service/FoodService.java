package com.restaurant.service;

import com.restaurant.model.FoodItem;
import com.restaurant.repository.FoodRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FoodService {

    @Autowired
    private FoodRepository foodRepository;

    public List<FoodItem> getAllFoodItems() {
        return foodRepository.findAll();
    }

    public Optional<FoodItem> getFoodItemById(Long id) {
        return foodRepository.findById(id);
    }

    public FoodItem addFoodItem(FoodItem foodItem) {
        return foodRepository.save(foodItem);
    }

    public FoodItem updateFoodItem(Long id, FoodItem updatedFood) {
        return foodRepository.findById(id)
                .map(food -> {
                    food.setName(updatedFood.getName());
                    food.setDescription(updatedFood.getDescription());
                    food.setPrice(updatedFood.getPrice());
                    return foodRepository.save(food);
                })
                .orElseThrow(() -> new RuntimeException("Food item not found"));
    }

    public void deleteFoodItem(Long id) {
        foodRepository.deleteById(id);
    }
}
