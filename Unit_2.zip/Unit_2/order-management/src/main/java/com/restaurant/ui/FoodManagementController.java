package com.restaurant.ui;

import com.restaurant.model.FoodItem;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Node;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class FoodManagementController {

    private final String BASE_URL = "http://localhost:8080/api/food";
    private final RestTemplate restTemplate = new RestTemplate();

    @FXML private TableView<FoodItem> foodTable;
    @FXML private TableColumn<FoodItem, Number> colId;
    @FXML private TableColumn<FoodItem, String> colName;
    @FXML private TableColumn<FoodItem, String> colDescription;
    @FXML private TableColumn<FoodItem, Number> colPrice;

    @FXML private TextField foodName;
    @FXML private TextField foodDescription;
    @FXML private TextField foodPrice;

    @FXML
    public void initialize() {
        // Bind TableView columns
        colId.setCellValueFactory(cellData -> cellData.getValue().idProperty());
        colName.setCellValueFactory(cellData -> cellData.getValue().nameProperty());
        colDescription.setCellValueFactory(cellData -> cellData.getValue().descriptionProperty());
        colPrice.setCellValueFactory(cellData -> cellData.getValue().priceProperty());

        loadFoodItems();
    }

    private void loadFoodItems() {
        try {
            FoodItem[] foodItemsArray = restTemplate.getForObject(BASE_URL, FoodItem[].class);
            List<FoodItem> foodItems = (foodItemsArray != null) ? Arrays.asList(foodItemsArray) : List.of();
            ObservableList<FoodItem> data = FXCollections.observableArrayList(foodItems);
            foodTable.setItems(data);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("❌ Error loading food items.");
        }
    }

    @FXML
    public void addFood() {
        if (foodName.getText().isEmpty() || foodDescription.getText().isEmpty() || foodPrice.getText().isEmpty()) {
            System.out.println("❌ Please fill in all fields.");
            return;
        }

        try {
            FoodItem foodItem = new FoodItem(foodName.getText(), foodDescription.getText(), Double.parseDouble(foodPrice.getText()));
            restTemplate.postForObject(BASE_URL, foodItem, FoodItem.class);
            loadFoodItems();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void updateFood() {
        FoodItem selected = foodTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            selected.setName(foodName.getText());
            selected.setDescription(foodDescription.getText());
            selected.setPrice(Double.parseDouble(foodPrice.getText()));
            restTemplate.put(BASE_URL + "/" + selected.getId(), selected);
            loadFoodItems();
        }
    }

    @FXML
    public void deleteFood() {
        FoodItem selected = foodTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            restTemplate.delete(BASE_URL + "/" + selected.getId());
            loadFoodItems();
        }
    }

    @FXML
    public void goBack(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/ui/LandingPage.fxml"));
        Parent root = loader.load();
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 800, 600)); // Set the scene size
        stage.show();
    }
}
