package com.restaurant.controller;

import com.restaurant.model.FrontService;
import com.restaurant.service.FrontServiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/frontservices") // Base endpoint for front service operations
@CrossOrigin(origins = "http://localhost:4200") // Allow frontend access (adjust if needed)
public class FrontServiceController {

    @Autowired
    private FrontServiceService frontServiceService; // Inject FrontServiceService to handle business logic

    /**
     * Retrieve all front service orders.
     * @return List of all front service orders.
     */
    @GetMapping
    public List<FrontService> getAllFrontServices() {
        return frontServiceService.getAllOrders();
    }

    /**
     * Retrieve a specific front service order by its ID.
     * @param id The ID of the front service order.
     * @return ResponseEntity with the order or 404 if not found.
     */
    @GetMapping("/{id}")
    public ResponseEntity<FrontService> getFrontServiceById(@PathVariable Long id) {
        Optional<FrontService> order = frontServiceService.getOrderById(id);
        return order.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    /**
     * Add a new front service order.
     * @param frontService The front service order to be added.
     * @return ResponseEntity with the created order.
     */
    @PostMapping
    public ResponseEntity<FrontService> addFrontService(@RequestBody FrontService frontService) {
        FrontService createdOrder = frontServiceService.addOrder(frontService);
        return ResponseEntity.ok(createdOrder);
    }

    /**
     * Update an existing front service order by its ID.
     * @param id The ID of the front service order to be updated.
     * @param frontService The updated front service data.
     * @return ResponseEntity with the updated order.
     */
    @PutMapping("/{id}")
    public ResponseEntity<FrontService> updateFrontService(@PathVariable Long id, @RequestBody FrontService frontService) {
        FrontService updatedOrder = frontServiceService.updateOrder(id, frontService);
        return ResponseEntity.ok(updatedOrder);
    }

    /**
     * Delete a front service order by its ID.
     * @param id The ID of the front service order to be deleted.
     * @return ResponseEntity with no content (204 status).
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFrontService(@PathVariable Long id) {
        frontServiceService.deleteOrder(id);
        return ResponseEntity.noContent().build();
    }
}
