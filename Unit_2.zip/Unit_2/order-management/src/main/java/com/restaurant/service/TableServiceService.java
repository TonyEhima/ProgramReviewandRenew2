package com.restaurant.service;

import com.restaurant.model.TableService;
import com.restaurant.repository.TableServiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TableServiceService {

    @Autowired
    private TableServiceRepository tableServiceRepository;

    public List<TableService> getAllTables() {
        return tableServiceRepository.findAll();
    }

    public Optional<TableService> getTableById(Long id) {
        return tableServiceRepository.findById(id);
    }

    public TableService addTable(TableService table) {
        return tableServiceRepository.save(table);
    }

    public TableService updateTable(Long id, TableService updatedTable) {
        return tableServiceRepository.findById(id)
                .map(table -> {
                    table.setTableNumber(updatedTable.getTableNumber());
                    table.setStatus(updatedTable.getStatus());
                    return tableServiceRepository.save(table);
                })
                .orElseThrow(() -> new RuntimeException("Table not found"));
    }

    public void deleteTable(Long id) {
        tableServiceRepository.deleteById(id);
    }
}
