package com.restaurant.service;

import com.restaurant.model.FrontService;
import com.restaurant.repository.FrontServiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FrontServiceService {

    @Autowired
    private FrontServiceRepository frontServiceRepository;

    public List<FrontService> getAllOrders() {
        return frontServiceRepository.findAll();
    }

    public Optional<FrontService> getOrderById(Long id) {
        return frontServiceRepository.findById(id);
    }

    public FrontService addOrder(FrontService order) {
        return frontServiceRepository.save(order);
    }

    public FrontService updateOrder(Long id, FrontService updatedOrder) {
        return frontServiceRepository.findById(id)
                .map(order -> {
                    order.setCustomerName(updatedOrder.getCustomerName());
                    order.setOrderDetails(updatedOrder.getOrderDetails());
                    order.setStatus(updatedOrder.getStatus());
                    return frontServiceRepository.save(order);
                })
                .orElseThrow(() -> new RuntimeException("Order not found"));
    }

    public void deleteOrder(Long id) {
        frontServiceRepository.deleteById(id);
    }
}
