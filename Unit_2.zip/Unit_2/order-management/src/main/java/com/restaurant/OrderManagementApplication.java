package com.restaurant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class OrderManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(OrderManagementApplication.class, args);
        System.out.println("✅ Order Management System is running on http://localhost:8080");
    }
}

@RestController
@RequestMapping("/")
class HealthCheckController {

    @GetMapping
    public String healthCheck() {
        return "✅ Order Management System is running!";
    }
}
