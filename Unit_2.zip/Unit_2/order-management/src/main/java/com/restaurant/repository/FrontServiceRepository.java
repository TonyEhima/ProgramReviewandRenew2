package com.restaurant.repository;

import com.restaurant.model.FrontService;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FrontServiceRepository extends JpaRepository<FrontService, Long> {
    // Additional custom queries can be added if needed
}
