package com.restaurant.ui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Node;
import java.io.IOException;

public class LandingPageController {

    @FXML
    private void handleFoodManagement(ActionEvent event) throws IOException {
        loadPage(event, "/ui/FoodManagement.fxml");
    }

    @FXML
    private void handleFrontService(ActionEvent event) throws IOException {
        loadPage(event, "/ui/FrontServices.fxml"); // Ensure correct filename
    }

    @FXML
    private void handleTableService(ActionEvent event) throws IOException {
        loadPage(event, "/ui/TableServices.fxml"); // Ensure correct filename
    }

    private void loadPage(ActionEvent event, String fxmlFile) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root, 800, 600)); // Adjust size if needed
            stage.show();
        } catch (IOException e) {
            e.printStackTrace(); 
            System.err.println("❌ ERROR: Unable to load " + fxmlFile);
        }
    }
}
