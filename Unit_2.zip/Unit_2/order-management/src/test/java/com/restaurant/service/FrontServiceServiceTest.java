package com.restaurant.service;

import com.restaurant.model.FrontService;
import com.restaurant.repository.FrontServiceRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class FrontServiceServiceTest {

    @Mock
    private FrontServiceRepository frontServiceRepository;

    @InjectMocks
    private FrontServiceService frontServiceService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllOrders_Normal() {
        List<FrontService> mockOrders = Arrays.asList(
                new FrontService("Alice", "Burger and Fries", "Pending"),
                new FrontService("Bob", "Pizza and Soda", "Completed")
        );
        when(frontServiceRepository.findAll()).thenReturn(mockOrders);

        List<FrontService> result = frontServiceService.getAllOrders();

        assertEquals(2, result.size());
        assertEquals("Alice", result.get(0).getCustomerName());
    }

    @Test
    void testGetOrderById_Null() {
        when(frontServiceRepository.findById(100L)).thenReturn(Optional.empty());

        Optional<FrontService> result = frontServiceService.getOrderById(100L);

        assertFalse(result.isPresent());
    }

    @Test
    void testAddOrder_EdgeCase() {
        FrontService emptyOrder = new FrontService("", "", "");
        when(frontServiceRepository.save(any(FrontService.class))).thenReturn(emptyOrder);

        FrontService result = frontServiceService.addOrder(emptyOrder);

        assertEquals("", result.getCustomerName());
    }
}
