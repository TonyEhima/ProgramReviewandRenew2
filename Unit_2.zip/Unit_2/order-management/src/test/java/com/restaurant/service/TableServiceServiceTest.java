package com.restaurant.service;

import com.restaurant.model.TableService;
import com.restaurant.repository.TableServiceRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class TableServiceServiceTest {

    @Mock
    private TableServiceRepository tableServiceRepository;

    @InjectMocks
    private TableServiceService tableServiceService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllTables_Normal() {
        List<TableService> mockTables = Arrays.asList(
                new TableService(1, "Available"),
                new TableService(2, "Reserved")
        );
        when(tableServiceRepository.findAll()).thenReturn(mockTables);

        List<TableService> result = tableServiceService.getAllTables();

        assertEquals(2, result.size());
        assertEquals(1, result.get(0).getTableNumber());
    }

    @Test
    void testGetTableById_Null() {
        when(tableServiceRepository.findById(200L)).thenReturn(Optional.empty());

        Optional<TableService> result = tableServiceService.getTableById(200L);

        assertFalse(result.isPresent());
    }

    @Test
    void testAddTable_EdgeCase() {
        TableService emptyTable = new TableService(-1, "");
        when(tableServiceRepository.save(any(TableService.class))).thenReturn(emptyTable);

        TableService result = tableServiceService.addTable(emptyTable);

        assertEquals(-1, result.getTableNumber());
    }
}
