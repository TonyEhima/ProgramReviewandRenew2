package com.restaurant.controller;

import com.restaurant.model.FrontService;
import com.restaurant.service.FrontServiceService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class FrontServiceControllerTest {

    @Mock
    private FrontServiceService frontServiceService;

    @InjectMocks
    private FrontServiceController frontServiceController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetFrontServiceById() {
        FrontService frontService = new FrontService("John Doe", "Table for 2", "Reserved");
        when(frontServiceService.getOrderById(1L)).thenReturn(Optional.of(frontService));

        ResponseEntity<FrontService> response = frontServiceController.getFrontServiceById(1L);

        assertNotNull(response);
        assertNotNull(response.getBody()); // Prevent Null Pointer Exception
        assertEquals("Reserved", response.getBody().getStatus());
    }
}
