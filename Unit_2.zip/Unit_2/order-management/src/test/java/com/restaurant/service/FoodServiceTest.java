package com.restaurant.service;

import com.restaurant.model.FoodItem;
import com.restaurant.repository.FoodRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class FoodServiceTest {

    @Mock
    private FoodRepository foodRepository;

    @InjectMocks
    private FoodService foodService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    /** Normal input test */
    @Test
    void testGetAllFoodItems_Normal() {
        List<FoodItem> mockItems = Arrays.asList(
                new FoodItem("Burger", "Tasty beef burger", 9.99),
                new FoodItem("Pizza", "Cheese pizza", 12.99)
        );
        when(foodRepository.findAll()).thenReturn(mockItems);

        List<FoodItem> result = foodService.getAllFoodItems();

        assertEquals(2, result.size());
        assertEquals("Burger", result.get(0).getName());
    }

    /** Null test (FoodItem ID not found) */
    @Test
    void testGetFoodItemById_Null() {
        when(foodRepository.findById(100L)).thenReturn(Optional.empty());

        Optional<FoodItem> result = foodService.getFoodItemById(100L);

        assertFalse(result.isPresent());
    }

    /** Edge case test: Empty food item */
    @Test
    void testAddFoodItem_EdgeCase_Empty() {
        FoodItem emptyFood = new FoodItem("", "", 0.0);
        when(foodRepository.save(any(FoodItem.class))).thenReturn(emptyFood);

        FoodItem result = foodService.addFoodItem(emptyFood);

        assertEquals("", result.getName());
        assertEquals(0.0, result.getPrice());
    }

    /** Null test: Adding a `null` food item */
    @Test
    void testAddFoodItem_NullInput() {
        when(foodRepository.save(null)).thenThrow(new IllegalArgumentException("Food item cannot be null"));

        assertThrows(IllegalArgumentException.class, () -> foodService.addFoodItem(null));
    }

    /** Edge case test: High price value */
    @Test
    void testAddFoodItem_EdgeCase_HighPrice() {
        FoodItem expensiveFood = new FoodItem("Gold Steak", "Luxury steak", 99999.99);
        when(foodRepository.save(any(FoodItem.class))).thenReturn(expensiveFood);

        FoodItem result = foodService.addFoodItem(expensiveFood);

        assertEquals("Gold Steak", result.getName());
        assertEquals(99999.99, result.getPrice());
    }
}
