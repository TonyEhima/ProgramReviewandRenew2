package com.restaurant.controller;

import com.restaurant.model.FoodItem;
import com.restaurant.service.FoodService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class FoodControllerTest {

    @Mock
    private FoodService foodService;

    @InjectMocks
    private FoodController foodController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetFoodItemById() {
        FoodItem foodItem = new FoodItem("Pasta", "Creamy Alfredo pasta", 10.99);
        when(foodService.getFoodItemById(1L)).thenReturn(Optional.of(foodItem));

        ResponseEntity<FoodItem> response = foodController.getFoodItemById(1L);

        assertNotNull(response);
        assertNotNull(response.getBody()); // Prevent Null Pointer Exception
        assertEquals(10.99, response.getBody().getPrice());
    }
}
