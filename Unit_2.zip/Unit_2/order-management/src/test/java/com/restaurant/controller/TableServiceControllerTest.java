package com.restaurant.controller;

import com.restaurant.model.TableService;
import com.restaurant.service.TableServiceService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class TableServiceControllerTest {

    @Mock
    private TableServiceService tableServiceService;

    @InjectMocks
    private TableServiceController tableServiceController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetTableById() {
        TableService tableService = new TableService(5, "Occupied");
        when(tableServiceService.getTableById(5L)).thenReturn(Optional.of(tableService));

        ResponseEntity<TableService> response = tableServiceController.getTableById(5L);

        assertNotNull(response);
        assertNotNull(response.getBody()); // Prevent Null Pointer Exception
        assertEquals("Occupied", response.getBody().getStatus());
    }
}
