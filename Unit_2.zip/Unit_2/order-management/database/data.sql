-- Insert sample data into food_items
INSERT INTO food_items (name, description, price) VALUES 
('Burger', 'Tasty beef burger', 9.99),
('Margherita Pizza', 'Fresh basil with extra mozzarella cheese', 13.99),
('Grilled Chicken', 'Tender grilled chicken breast with herbs', 10.99),
('Pasta Alfredo', 'Creamy Alfredo sauce over fettuccine pasta', 11.99),
('Caesar Salad', 'Fresh romaine lettuce with Caesar dressing', 7.49);

-- Insert sample data into front_services
INSERT INTO front_services (customer_name, order_details, status) VALUES 
('John Doe', 'Burger and Fries', 'Pending'),
('Jane Smith', 'Margherita Pizza', 'Completed'),
('Alice Johnson', 'Grilled Chicken', 'Canceled');

-- Insert sample data into table_services
INSERT INTO table_services (table_number, status) VALUES 
(1, 'Available'),
(2, 'Reserved'),
(3, 'Occupied');
